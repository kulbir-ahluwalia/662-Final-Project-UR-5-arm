# robotiq

[![Build Status](https://travis-ci.org/utecrobotics/robotiq.svg?branch=master)](https://travis-ci.org/utecrobotics/robotiq)

Visualization and simulation (in Gazebo) of a Robotiq gripper
